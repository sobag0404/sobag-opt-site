# Active Context

Last updated: 2026-06-09

## Token-Saving Rule
- Читать этот файл первым.
- Старый чат, большие handoff-файлы и длинные логи открывать только если не хватает конкретной детали.
- После важных изменений кратко обновлять этот файл.

## Project
- Путь к проекту: `C:\Users\SoBag\OneDrive\Документы\New project\sobag-opt-site`
- Репозиторий: `https://github.com/sobag0404/sobag-opt-site`
- Основная ветка: `main`
- Production/preview URL: `https://sobag-shop.online`, fallback `https://sobag-opt-site.vercel.app`
- Основной стек: static HTML/CSS/JS, Vercel API routes, Upstash Redis / Vercel KV-compatible storage.
- Где лежит основной код: `app.js`, `cart.js`, HTML pages in repo root, shared shell in `components/site-shell.js`, API in `api/`.
- Где лежат тесты/проверки: `tools/autofix.mjs`, `tools/ui-smoke.spec.js`, `tools/audit_catalog.py`.
- Локальный запуск: `npm run dev:static` для легкой верстки без API; `npm run dev:vercel` только для Vercel Functions/env проверок.

## Current Product / Goal
- Что это за проект: B2B-сайт Sobag Opt для оптовой продажи текстиля с каталогом, вариантами товаров, корзиной-КП, заявками, аккаунтами, ролями и админ-инструментами.
- Главная цель сейчас: двигаться по roadmap к удобному оптовому магазину: сохраненные КП 2.1, CRM заказов/клиентов, Import/PIM 2.0, SEO/content, performance, QA/security.
- Что важно не сломать: каталог, поиск, карточку товара, корзину/КП, авторизацию, заказы, админку, storage-ready production API, текущий черно-белый дневной стиль.

## Current User Preferences
- Язык ответов: русский.
- Дизайн/стиль: дневная тема черно-бело-серая; ночная тема может использовать оранжевые акценты.
- Ограничения: не использовать старый Tilda-сайт и его изображения; не коммитить большие папки фото/импорт-выводы; беречь лимит Vercel Hobby Functions.
- Что нельзя делать без разрешения: добавлять секреты, `.env`, токены, пароли, cookies, дампы БД, приватные SSH-ключи; менять production/deploy/cache/user data; делать крупные архитектурные изменения.

## Latest Done
- Current pass 2026-06-09: added a real FAQ block to `business.html` for wholesale order questions, added `syncFaqJsonLd()` in `app.js` to publish `FAQPage` JSON-LD from visible `[data-faq-schema]` content, styled the FAQ in `styles.css`, and added Playwright smoke coverage for the visible FAQ plus schema. Roadmap now marks Product/FAQ schema done.
- Current pass 2026-06-04: started SEO/schema work with public Product JSON-LD for the product modal/detail state. `app.js` now writes `#sobag-product-jsonld` after `/api/catalog-detail` hydration, includes Product name/description/baseSku/mpn/category/brand/images/RUB AggregateOffer and approved review aggregate data when present, skips admin catalog product previews, and removes stale Product JSON-LD on modal close. `tools/ui-smoke.spec.js` now verifies schema creation from detail endpoint data and cleanup after closing the modal. FAQ schema is now covered by the 2026-06-09 business FAQ pass.
- Current pass 2026-06-04: added lightweight error monitoring/log review workflow. Shared `api/_lib/http.js` `handleError` now accepts `req`, adds `requestId` to error JSON and `X-Sobag-Request-Id`, and writes structured `api_error` JSON logs for 5xx without production stack traces or query strings. API routes now pass `req` to `handleError`. New `tools/error-log-audit.mjs`, npm script `audit:errors`, AutoFix coverage, and `docs/error-log-review.md` runbook. Roadmap QA/Ops error/log review is now checked.
- Current pass 2026-06-04: added periodic API access audit slice. New `tools/access-audit.mjs` keeps a static route/method/role matrix for every API route, checks admin `requireUser` roles, method guards, owner checks for buyer order comments, and password-field sanitization. Added npm script `audit:access`; AutoFix now runs the audit, so the existing push/PR/weekly `autofix-check` workflow covers periodic access audit. `/api/health` is now GET-only via `methodNotAllowed`. New doc: `docs/access-audit.md`.
- Current pass 2026-06-04: wired production smoke into post-push/post-deploy routine. Added `.github/workflows/production-smoke.yml`, triggered after successful `autofix-check` push to `main` and via manual dispatch for fallback/preview URLs. `tools/production-smoke.mjs` now supports `--retries` and `--retry-delay`; workflow runs read-only live GET smoke with retries and no secrets.
- Current pass 2026-06-04: added read-only production smoke automation slice. New `tools/production-smoke.mjs` checks `/`, `/catalog`, `/cart`, and `/api/health` with GET-only requests; supports `--base-url`, repeated `--path`, `--timeout`, `--json`, and offline `--self-test`; npm scripts `smoke:prod` and `smoke:prod:self-test` were added; AutoFix runs only the self-test so local checks do not touch production; docs now include `docs/deploy-checklist.md`.
- Current pass 2026-06-04: active public catalog/search server-query listing pages now skip full `/api/catalog` bootstrap when `/api/catalog-query` succeeds, while keeping full/static fallback when the query endpoint is unavailable. Playwright smoke asserts `/api/catalog` is not requested in the intercepted server-query scenario.
- Current pass 2026-06-04: catalog/search visible filter controls now use server `facetOptions` from `/api/catalog-query` when available, with local fallback. Backend facet options are calculated per bucket without that bucket's own filter, so alternative values stay visible while other filters apply. Added backend smoke and Playwright coverage for server facet options.
- Current pass 2026-06-04: public catalog/search list now progressively renders compact cards from `/api/catalog-query`, uses server total counts and cursor "load more", and falls back to the old local list path when the endpoint is unavailable. Added Playwright smoke coverage for intercepted query endpoint and cursor pagination.
- Current pass 2026-06-04: frontend product modal now hydrates public product details from `/api/catalog-detail` before rendering, with static/local fallback and admin-page skip. Added Playwright smoke coverage for intercepted detail endpoint.
- Current pass 2026-06-04: first server-side catalog query/detail performance slice is implemented. Added `api/_lib/catalog-query.js`, public `/api/catalog-query` for published card results with q/filter/sort/page/cursor/facets, public `/api/catalog-detail` for full published product details, `tools/catalog-query-smoke.mjs` in AutoFix, and `docs/catalog-server-api.md`. Old `/api/catalog` remains compatible.
- Current pass 2026-06-04: admin PIM diagnostics/export slice is implemented. Added read-only `/api/admin/pim` for `admin/content` roles, JSON views `summary/full/products/variants/images/taxonomies/import-batches`, CSV exports for table views, `api/_lib/pim-report.js`, and `tools/pim-report-smoke.mjs` in AutoFix. Updated `docs/pim-normalized-payload.md` and roadmap.
- Current pass 2026-06-04: first normalized PIM sidecar slice is implemented. Added `api/_lib/pim.js`, `saveCatalog` now stores `pim` next to the current `products` array, import batch apply/rollback rebuilds sidecar metadata, public `/api/catalog` strips `pim`, admin catalog can inspect it, and `tools/pim-smoke.mjs` is included in AutoFix. New doc: `docs/pim-normalized-payload.md`.
- Current pass 2026-06-04: готов responsive image variants срез. `tools/bulk-upload-product-photos.mjs` поддерживает `--responsive`, `--variant-widths`, `--variant-formats`, `--variant-quality`; dry-run планирует `ready_variant` без Blob/Sharp; реальная генерация требует optional `sharp` и грузит WebP/AVIF variants через object-storage adapter; `images[].variants` сохраняются в API/frontend normalization/validator; product cards, product modal, thumbnails и admin cards используют WebP variants как `srcset`, AVIF metadata сохранена для будущего `<picture>` pass.
- Current pass 2026-06-04: готов bulk CLI upload path для больших фото-партий. Добавлен `tools/bulk-upload-product-photos.mjs`: dry-run сканирует products JSON и папки фото, пишет CSV report; реальный upload идет file-by-file через `api/_lib/object-storage.js`, без JSON body `/api/admin/product-images`; output products JSON получает `images` metadata и совместимые `image/gallery`; report statuses `ready/uploaded/skipped/missing/failed`; добавлен `tools/bulk-upload-product-photos.test.mjs`, он включен в `tools/autofix.mjs`; npm script `upload:photos`.
- Current pass 2026-06-04: готов явный `updateExisting` режим в `admin-import.html`. Перед загрузкой Excel/CSV есть чекбокс `Обновлять существующие товары по baseSku`; preview передает `updateExisting` в `/api/admin/import-batches`; карточки партий показывают режим; локальный fallback apply умеет обновлять существующие товары без удаления каталога; при обновлении сохраняются существующие `id/status/image/gallery/images` и важные optional поля, если файл их не передал; smoke покрывает чекбокс и label режима.
- Текущий проход 2026-06-04: готов admin import photo flow. В `admin-import.html` добавлен блок фото текущего предпросмотра: выбор файлов или папки, match по `baseSku/photoFolder/id`, отчет `ready/missing/repeated/uploaded/failed`, CSV отчета, upload через `/api/admin/product-images`, merge Blob/S3 metadata в `product.images`, затем автоматическое создание свежего preview batch с image metadata. Smoke покрывает photo preview report без настоящего Blob env.
- Текущий проход 2026-06-04: готов первый backend-срез фото-хранилища. Добавлен `api/_lib/object-storage.js` с provider switch, Vercel Blob provider, S3-compatible placeholder и interface `upload/getPublicUrl/deleteOrMarkUnused/listByProduct`; добавлен `/api/admin/product-images` для ролей `admin/content`; `/api/health` показывает безопасный objectStorage status; продукты сохраняют `images` metadata (`url/storageKey/provider/width/height/mime/uploadedAt`) рядом со старыми `image/gallery`; валидатор допускает remote URL и проверяет metadata; `.gitignore` усилен для bulk/raw photo folders.
- Текущий проход 2026-06-04: готов первый срез Import Batches 2.0. Добавлен `/api/admin/import-batches` для ролей `admin/content`, отдельное хранение партий, preview без изменения каталога, отчет created/skipped/updated/errors, проверки дублей `baseSku` и variant SKU, apply со snapshot каталога, rollback только последней примененной партии, а в `admin-import.html` появились карточки партий, кнопки применить/отклонить/откатить/скачать CSV. CSV в браузере теперь читается встроенным parser fallback без зависимости от внешнего XLSX CDN.
- Текущий проход 2026-06-04: готов первый срез Import/PIM 2.0 - статусы публикации товаров `draft/published/hidden/archive` во фронтенде, админке, API, локальном импортере и шаблонах. Публичный `/api/catalog` отдает только `published`, новые импорты по умолчанию становятся `draft`, полные проверки `npm.cmd run check` и `npm.cmd run ui:smoke` прошли.
- Последние важные изменения: добавлена CRM-лента по заказам: внутренние комментарии менеджеров, комментарии видимые покупателю, сообщения покупателя по заказу, фильтрация внутренних записей из покупательских API, клиентская панель в админском списке заказов с сегментами; сохраненные КП 2.1 и отзывы товаров уже реализованы ранее.
- Локальная RAM-правка: осиротевшие `vercel dev --listen 4173` и `@vercel/node/dist/dev-server.mjs` процессы были точечно остановлены; добавлен легкий `tools/static-server.mjs` и npm scripts `dev:static`/`dev:vercel`.
- Последние коммиты до handoff: `7788c84 Protect internal saved quote notes`, `5fb959e Add saved quote workspace`, `c252c4c Add product reviews workflow`.
- Что уже проверено в текущем проходе: `node --check app.js`; `node --check api/admin/orders.js`; `node --check api/orders.js`; `node --check api/auth/me.js`; `node --check tools/autofix.mjs`; `node --check tools/ui-smoke.spec.js`; `npm.cmd run check`; focused smoke `manager order|account favorites`; focused smoke `mobile pages`.
- Важно: `npm.cmd run check` теперь не падает без установленного Python, но явно пропускает Python syntax checks; на новом устройстве желательно установить Python и вернуть полную проверку импортеров.

## Current Next Work
- Current next task: continue SEO/content with final legal/contact/company copy, category/collection/holiday landing copy, final Yandex map data after confirmation, or return to performance items that need real catalog growth. QA/Ops current checklist items are done.
- Следующая задача: либо bulk CLI/importer upload path для больших фото-партий в Blob/S3 без JSON body limits, либо явный `updateExisting` режим в UI import batches.
- Следующий PIM шаг: нормализованный payload product/variant/images/tags/categories/collections/holidays/import batch metadata, публичный `/api/catalog` только для `published`, responsive WebP/AVIF strategy после bulk storage.
- Риски: не удалить старые товары без команды, не создать дубли по `baseSku`, не сломать текущий каталог, цены, варианты, реальные фото и импортный workflow.

## Useful Files
- Главные файлы проекта: `app.js`, `cart.js`, `styles.css`, `components/site-shell.js`, `data/products-live.json`.
- Документация: `docs/roadmap-checklist.md`, `docs/ai-handoff/CURRENT_STATUS.md`, `docs/product-import.md`, `docs/object-storage.md`, `docs/backend-security.md`, `docs/deploy-checklist.md`, `docs/access-audit.md`, `docs/error-log-review.md`.
- Проверки: `package.json`, `tools/autofix.mjs`, `tools/ui-smoke.spec.js`, `tools/audit_catalog.py`.
- API/Backend: `api/_lib/store.js`, `api/_lib/auth.js`, `api/_lib/http.js`, `api/_lib/object-storage.js`, `api/catalog.js`, `api/auth/me.js`, `api/orders.js`, `api/admin/orders.js`, `api/admin/users.js`, `api/admin/catalog.js`, `api/admin/content.js`, `api/admin/product-images.js`.

## Verification
- Current device note: `git` works via `C:\Program Files\Git\cmd\git.exe`; `node`, `npm.cmd`, `python`, and `py` are available in PATH on this device.
- Current business FAQ schema pass verification: `node --check app.js`; `node --check tools/ui-smoke.spec.js`; `git diff --check`; `python -m py_compile tools/product_importer.py tools/publish_imported_products.py tools/audit_catalog.py`; `npm.cmd run check`; focused smoke `npm.cmd run ui:smoke -- --grep "business page exposes visible FAQ"`; full `npm.cmd run ui:smoke`.
- Current product structured data pass verification: `node --check app.js`; `node --check tools/ui-smoke.spec.js`; focused smoke `ui-smoke --grep "product modal hydrates detail"` passed and checks Product JSON-LD creation/removal; `git diff --check`; bundled Python `py_compile`; bundled Node `tools/autofix.mjs --check`; full bundled Playwright `tools/ui-smoke.spec.js` 10/10. In-app Browser was attempted but `iab` was unavailable in this session.
- Current error-log workflow pass verification: `node --check api/_lib/http.js`; `node --check tools/error-log-audit.mjs`; `node tools/error-log-audit.mjs`; `git diff --check`; bundled Python `py_compile`; bundled Node `tools/autofix.mjs --check` (now includes error-log audit); full bundled Playwright `tools/ui-smoke.spec.js`.
- Current access-audit pass verification: `node --check tools/access-audit.mjs`; `node --check api/health.js`; `node tools/access-audit.mjs`; `git diff --check`; bundled Python `py_compile`; bundled Node `tools/autofix.mjs --check` (now includes access audit); full bundled Playwright `tools/ui-smoke.spec.js`.
- Current production-smoke workflow pass verification: `node --check tools/production-smoke.mjs`; `node tools/production-smoke.mjs --self-test --retries 1 --retry-delay 10`; `git diff --check`; bundled Python `py_compile`; bundled Node `tools/autofix.mjs --check` (includes production smoke self-test only, no live production); full bundled Playwright `tools/ui-smoke.spec.js`.
- Previous production-smoke script pass verification: `node --check tools/production-smoke.mjs`; `node tools/production-smoke.mjs --self-test`; `git diff --check`; bundled Python `py_compile`; bundled Node `tools/autofix.mjs --check` (includes production smoke self-test only, no live production); full bundled Playwright `tools/ui-smoke.spec.js`.
- Current no-full-catalog-bootstrap pass verified: `node --check app.js`, `node --check tools/ui-smoke.spec.js`, focused `ui-smoke --grep "catalog list renders server query"` with `/api/catalog` blocked/asserted unused, `git diff --check`, bundled Python `py_compile`, bundled Node `tools/autofix.mjs --check`, and full bundled Playwright `tools/ui-smoke.spec.js` 10/10.
- Current server facet-options pass verified: `node --check api/_lib/catalog-query.js`, `node --check app.js`, `node --check tools/catalog-query-smoke.mjs`, `node --check tools/ui-smoke.spec.js`, `node tools/catalog-query-smoke.mjs`, `git diff --check`, bundled Python `py_compile`, bundled Node `tools/autofix.mjs --check`, and full bundled Playwright `tools/ui-smoke.spec.js` 10/10.
- Current catalog/search query-list pass verified: `node --check app.js`, `node --check tools/ui-smoke.spec.js`, focused `ui-smoke --grep "catalog list renders server query"`, `git diff --check`, bundled Python `py_compile`, bundled Node `tools/autofix.mjs --check`, and full bundled Playwright `tools/ui-smoke.spec.js` 10/10.
- Какие команды запускать перед финальным ответом: `npm.cmd run check`; для JS-изменений `node --check <file>`; для UI-изменений `npm.cmd run ui:smoke` или focused smoke.
- Что проверять вручную: затронутые страницы, product modal, header search, cart/account/admin flows по риску изменения.
- Что проверять после деплоя: affected production URL, `/api/health`, storage-ready signal, отсутствие visual regressions на ключевых страницах.

## Working Rule
1. Сначала читать `ACTIVE_CONTEXT.md`.
2. Потом `git status --short --branch`.
3. Затем открывать только файлы, нужные для текущей задачи.
4. Не читать весь старый чат без причины.
5. Не менять архитектуру проекта на основании сжатого контекста.
6. Если информации не хватает, сначала искать в handoff/docs, а не выдумывать.
