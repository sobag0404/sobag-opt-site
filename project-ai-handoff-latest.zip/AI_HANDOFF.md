# Sobag Opt Site AI Handoff

Last updated: 2026-06-04

## Project

Sobag Opt is a B2B wholesale textile/catalog prototype for printed textile products: pillows, pillowcases, blankets, shoe bags, cooler covers, luggage covers, flags, removki/keychains, custom-print requests, carts, discounts, prototype accounts, admin/manager/content-manager workspaces, editable site content, server-backed cart/favorites prototype state through `/api/auth/me`, and local bulk product import tooling.

Repository:
- GitHub: `https://github.com/sobag0404/sobag-opt-site`
- Branch: `main`
- Primary production domain: `https://sobag-shop.online/`
- Vercel fallback/project domain: `https://sobag-opt-site.vercel.app/`

Latest functional commit before this handoff update:
- `7788c84 Protect internal saved quote notes`

## Current State

The project is a mostly static frontend with a small Vercel API layer.

Frontend:
- Pages are plain HTML files with shared JavaScript and CSS.
- Shared shell markup lives in `components/site-shell.js`.
- Main UI/state logic lives in `app.js`.
- Cart page logic lives in `cart.js`.
- Styling lives in `styles.css`.

Backend/storage:
- Vercel API routes under `api/` support auth, sessions, orders, admin role/order updates, and health checks.
- Upstash Redis / Vercel KV-compatible storage is configured in Vercel.
- Do not store or paste env values in chat or docs.
- Health check: `https://sobag-shop.online/api/health` should return `{"ok":true,"storage":"ready"}`.

## Important Files

Use `docs/ai-handoff/ACTIVE_CONTEXT.md` as the short current working context to reduce token usage. Use the long handoff and live context only when a missing historical detail is needed.

- `index.html`: home page.
- `catalog.html`: catalog page with category home and product listing.
- `favorites.html`: separate favorites page.
- `custom.html`: custom-print request page.
- `marketplaces.html`: marketplace page.
- `about.html`: about page.
- `contacts.html`: contacts page with Yandex map iframe/link.
- `cart.html`: separate cart page.
- `components/site-shell.js`: shared top line, header, cart header, and footer.
- `app.js`: main site logic, catalog, filters, favorites, accounts, admin panel, content editing, orders, import/export.
- `cart.js`: cart page logic, checkout modal, discounts, promo code prototype.
- `styles.css`: shared UI styling, day/night themes, responsive layout, transitions.
- `api/`: Vercel API layer.
- `tools/product_importer.py`: local CSV/XLSX + photo-folder importer.
- `tools/publish_imported_products.py`: static preview product publisher for optimized WebP previews.
- `tools/autofix.mjs`: repository checks.
- `templates/sobag-products-template.csv` and `.xlsx`: downloadable product import templates.
- `docs/product-import.md`: current import workflow notes.
- `docs/backend-security.md`: backend/security setup notes.
- `vercel.json`: Vercel clean URLs, headers, and caching.

## Recently Completed

- Custom domain `sobag-shop.online` is connected to Vercel.
- Upstash Redis / Vercel KV storage is configured in Vercel.
- Production admin env variables are configured in Vercel without exposing values in repo.
- Header/footer shell was extracted into `components/site-shell.js`.
- Large pages were split so each page owns only its own content sections.
- AutoFix now checks shell ownership, page section ownership, image hints, and inline style regressions.
- Motion/transition layer was added, then tuned to avoid catalog flicker.
- Product-card favorite clicks now update only the clicked state and header counter instead of rebuilding the entire product grid.
- Same-page navigation flicker was fixed:
  - clicking `Каталог` while already in catalog no longer reloads the page;
  - same-route links and `href="#"` placeholders no longer jump/reload visually;
  - cart page has the same same-route/placeholder guard.
- Catalog product cards no longer replay entrance animation on every product render.
- Catalog home tiles animate only on first render.
- Catalog B2B UX pass was added on 2026-06-03:
  - active filter chips above the product grid;
  - first 120 products rendered with "show more" pagination to reduce catalog DOM weight;
  - recently viewed products;
  - related products inside the product modal;
  - variant matrix for type/size/material/SKU/price/quick quantity;
  - product price CSV download from the modal;
  - Organization, CollectionPage, and BreadcrumbList JSON-LD on catalog states.
- Cart page now behaves more like a commercial proposal:
  - discount is calculated from basket amount;
  - save draft;
  - download XLSX with CSV fallback;
  - print commercial proposal.
- Production verification after the B2B UX pass succeeded on `https://sobag-shop.online` for `/`, `/catalog`, `/cart`, `/api/health`, fresh `app.js`/`cart.js`, and a Playwright spot-check.
- GitHub access audit was performed:
  - repo is private;
  - only collaborator found: `sobag0404`;
  - no pending invitations;
  - no deploy keys;
  - no webhooks;
  - no forks;
  - no tracked high-risk secret patterns found.
- Saved cart drafts / commercial proposal drafts 2.0 were added on 2026-06-03:
  - account saved drafts can be renamed;
  - saved drafts can be exported as XLSX, or CSV if SheetJS is unavailable;
  - saved drafts can be printed/saved as PDF through browser print;
  - saved drafts can be sent to the manager by creating a normal order through existing `/api/orders`;
  - sent drafts keep `status`, `sentAt`, and `sentOrderId`;
  - old saved cart objects remain compatible through normalization defaults.

## Current UX / Business Rules

- Day theme should stay black, white, and gray. Do not reintroduce orange into day theme.
- Night theme can use orange accents.
- Buttons should be uppercase, centered, and visually consistent.
- Product cards in catalog show:
  - square photo;
  - base SKU with copy button;
  - product name;
  - price as the button text.
- Product detail modal changes SKU, product name, unit price, and total by selected type, size, material, and quantity.
- Product detail default quantity is `0`, so opening a card does not affect basket discount until the buyer increases quantity.
- Variant SKU rule: `baseSku_ТИП_Размер_МАТ`, where `_` is the separator, type and material use the first 3 cleaned chars, and size is kept full.
- Cart minimum total is `30 000 ₽`.
- Basket discount tiers by cart sum:
  - `30 000 ₽`: 5%
  - `70 000 ₽`: 7%
  - `150 000 ₽`: 12%
  - `300 000 ₽`: 18%
- Quantity tiers still exist for some UI/calculation flows:
  - 30 items: 3%
  - 70 items: 7%
  - 150 items: 12%
  - 300 items: 18%
- Demo promo codes in `cart.js`:
  - `SOBAG5`
  - `OPT10`

## Product Import Notes

Recommended workflow:
1. Keep photos outside Git, for example in a local folder or synced Yandex Disk folder.
2. Use folder shape like `Фото товаров / Категория / Основной артикул / фото` when categories are known.
3. Run `tools/product_importer.py scan-photos` to generate a draft CSV/XLSX from folders.
4. Edit the generated table manually.
5. Use `;` inside list cells, especially for sizes, so decimal comma values like `3,5` remain valid.
6. Run the local importer against the edited table and photo root.
7. Publish only optimized/static preview assets intentionally.

Important import rules:
- Multiple categories are supported in `Категории` with `;`.
- If `Типы товара` contains `Подушка;Наволочка`, display names should adapt by type.
- Duplicate imports must be skipped/updated intentionally; do not delete existing products unless explicitly commanded.
- `tools/product_importer.py import --update-existing` intentionally updates existing products by `baseSku`; without that flag duplicate base SKUs are skipped.
- For flags, photo order is `1,2,3...`; for most other product categories, the highest numbered photo is main.

Ignored/generated import outputs:
- `local-import-output/`
- `assets/imported-products/`
- `data/products.import.json`
- `data/import-report.csv`

Large product-photo folders must not be committed to GitHub/Vercel.

## Important Constraints

- Do not use old Tilda site imagery or design as a visual source.
- Do not add secrets to repo, handoff files, ZIP, or chat:
  - no tokens;
  - no passwords;
  - no `.env`;
  - no SSH keys;
  - no cookies;
  - no database dumps;
  - no production credentials.
- Browser-local data is still used for some prototype UI states and admin content previews.
- Admin image uploads in the browser are not permanent production storage.
- A browser page cannot automatically read arbitrary folders from the user's PC; photo matching needs an explicit local importer or user-selected folder flow.
- For 10k+ products, keep moving toward real backend/database/object storage instead of Git-tracked static catalog data.

## Latest Account Drafts Update

- Date: 2026-06-03.
- Base commit before this update: `67e3f5e`.
- Added buyer profile fields in the account modal: name, phone, company, INN, city, and address.
- Added saved cart drafts: save a named draft from `/cart`, view saved drafts in the account modal, and restore/delete drafts from the account modal.
- Extended the existing `/api/auth/me` endpoint to persist profile data and saved carts without creating extra Serverless Functions.
- Store schema now includes `savedCarts`.
- HTML asset version is `20260603-account-drafts`.
- No secrets or production credentials were added.

## Latest B2B Profile Update

- Date: 2026-06-03.
- Continued the roadmap after saved carts: buyer profile now supports KPP, legal address, multiple company/requisite records, multiple delivery addresses, layout file references, default delivery/packaging, and reusable order comments.
- Cart checkout and catalog request form submit the new customer fields.
- Cart "use profile" fills the expanded B2B fields.
- `/api/auth/me` and `/api/orders` persist the expanded profile/order data without adding new Vercel Functions.
- Manager/admin order detail, customer detail, CSV exports, and print/PDF view include the expanded requisites.
- HTML asset version is `20260603-b2b-profile`.
- No secrets or production credentials were added.

## Latest Saved Quote Drafts 2.0 Update

- Date: 2026-06-03.
- Base commit before this update: `c1efddd`.
- Added saved commercial proposal draft management in the buyer account:
  - rename;
  - download XLSX with CSV fallback;
  - print / save as PDF via browser print;
  - send to manager;
  - restore to cart;
  - delete.
- Extended saved cart objects with compatible fields: `discount`, `status`, `sentAt`, and `sentOrderId`.
- `status` is normalized to `draft` or `sent`; older saved carts still open without manual migration.
- `send to manager` uses the existing `/api/orders` endpoint and does not add a new Vercel Function.
- The order comment includes that it was created from a saved commercial proposal draft.
- Sending requires profile company and phone so managers receive usable B2B contact data.
- Cart quote export now uses SheetJS XLSX when available and falls back to CSV.
- HTML asset version is `20260603-saved-quotes`.
- Feature commit: `53979c3 Improve saved quote drafts`.
- Production verification passed on `https://sobag-shop.online`:
  - `/` served fresh `20260603-saved-quotes`;
  - `/catalog?category=Подушки` rendered 120 product cards with no horizontal overflow;
  - `/cart` rendered the `Скачать XLSX` commercial proposal button;
  - `/api/health` returned `{"ok":true,"storage":"ready"}`.
- No secrets or production credentials were added.

## Latest Roadmap / Search Update

- Date: 2026-06-03.
- Added `docs/roadmap-checklist.md` with the remaining implementation checklist.
- Added `search.html` as a dedicated search results route.
- Header search now opens `/search?q=...`, preserving query state on refresh.
- Search results show count, "maybe you searched" suggestions, and quick filters by category, collection, holiday, and tag.
- Exact SKU-like queries with digits now rely on SKU matching, so `opt_22434` returns the matching product instead of all `opt_*` products.
- Product-modal SKU copy toast is above the modal layer.
- AutoFix mojibake guard now scans HTML, JS/MJS, CSS, MD, and JSON for common broken UTF-8 patterns.
- Product reviews were added to the roadmap as the next major feature: registered-user star/text reviews plus admin moderation.
- Commit `9d0d4f9 Add search results page and roadmap checklist` was pushed to `origin/main`.
- Production verification passed on `https://sobag-shop.online`: fresh marker `20260603-search-results`, `/`, `/catalog`, `/cart`, `/search?q=opt_22434`, `/api/health`, exact SKU search, and product-modal copy toast above the modal layer.

## Latest CRM / Device Handoff Update

- Date: 2026-06-04.
- Current branch: `main`.
- CRM order polish was implemented in the current handoff pass:
  - admin/manager order updates can append CRM thread entries;
  - manager entries can be `internal` or `customer`;
  - buyers can send customer-visible order messages from the account order history;
  - buyer-facing `/api/orders` and `/api/auth/me` strip internal CRM thread entries;
  - admin order cards show the communication thread and manager message form;
  - buyer order cards show public thread entries and a buyer message form;
  - admin orders page includes a customer segment panel based on the current filtered order list.
- AutoFix now tolerates a missing local Python installation by skipping only Python syntax checks with a warning; on a new device install Python to restore full importer syntax coverage.
- Smoke test hardening:
  - external CDN resources are aborted in UI smoke to keep local tests stable;
  - the document-load counter is protected from cross-origin iframe `localStorage` errors;
  - mobile overflow smoke uses a short lifecycle wait instead of hanging on slow external scripts.
- Local development RAM fix:
  - orphaned `vercel dev --listen 4173` and `@vercel/node/dist/dev-server.mjs` processes were identified and stopped by exact PID/command line;
  - `tools/static-server.mjs` was added for lightweight static UI development;
  - npm scripts now include `dev:static` for normal UI work and `dev:vercel` only when Vercel Functions/env are needed.
- Roadmap update: Order/customer CRM polish is marked done in `docs/roadmap-checklist.md`.
- Next major work after this handoff:
  1. Import/PIM 2.0: import batches, duplicate/error preview, created/skipped/updated reports, product statuses.
  2. Photo storage plan: choose Blob/S3/R2 and prepare non-Git image path scheme.
  3. Content/SEO fill-out: company/contact/business/marketplaces copy, FAQ/Product schema, Yandex map final setup.

Current verification in this pass:
- `node --check app.js`
- `node --check api/admin/orders.js`
- `node --check api/orders.js`
- `node --check api/auth/me.js`
- `node --check tools/autofix.mjs`
- `node --check tools/ui-smoke.spec.js`
- `npm.cmd run check`
- focused UI smoke: `manager order|account favorites`
- focused UI smoke: `mobile pages`

Full `npm.cmd run ui:smoke` should be rerun on the next device after clone/pull; before handoff, all previously failing focused scenarios were made green.

## Verification Status

Latest verified checks before this handoff update:
- `node --check app.js`
- `node --check cart.js`
- `node --check api/auth/me.js`
- `node --check api/orders.js`
- `node --check tools/ui-smoke.spec.js`
- `npm run check`
- `SOBAG_BASE_URL=http://127.0.0.1:4173 npm run ui:smoke` with 7/7 passing, including saved quote rename/export/send/restore checks.
- extra Playwright spot-check for `/catalog?category=Подушки`, product modal variant matrix/related products, and `/cart`.

## Current Focus

Current focus is stabilizing the prototype before continuing larger catalog/import/backend work:
- keep navigation smooth, without reload-like flicker;
- keep handoff docs current before moving between devices;
- continue buyer account/commercial proposal polish: saved drafts, repeat orders, company profiles, addresses, saved files/layouts, and order comments;
- continue polishing catalog/cart/admin UX;
- continue real product import workflow later.

If moving again after weekend work, repeat handoff preparation on that device before switching back.
